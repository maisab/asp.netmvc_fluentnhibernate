﻿using FluentNHibernate.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookStore.Models
{
    public class AuthorMap : ClassMap<Author>
    {

        public AuthorMap()
        {
            Id(x => x.Id)
                .GeneratedBy.Identity();
            Map(x => x.Name);
        }
    }
}
