﻿using FluentNHibernate.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookStore.Models
{
    public class BookMap : ClassMap<Book>
    {

        public BookMap()
        {
            Id(x => x.Id)
                .GeneratedBy.Identity();
            Map(x => x.Title);
            Map(x => x.Pages);
            Map(x => x.PurchasePrice);
            Map(x => x.SalePrice);

           HasManyToMany(x => x.Authors)
            .Access
            .CamelCaseField(Prefix.Underscore)
            .Cascade.SaveUpdate(); 
        }
    }
}
