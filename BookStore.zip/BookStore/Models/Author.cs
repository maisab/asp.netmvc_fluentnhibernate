﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookStore.Models
{
    public class Author
    {
        public virtual int Id { get; protected set; }
        public virtual string Name { get; set; }

        private readonly IList<Book> _books;
        public virtual IEnumerable<Book> Books { get { return _books; } }
    }
}
