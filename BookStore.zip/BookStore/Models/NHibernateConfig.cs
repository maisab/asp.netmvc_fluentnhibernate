﻿using FluentNHibernate.Cfg;
using FluentNHibernate.Cfg.Db;
using NHibernate;
using NHibernate.Tool.hbm2ddl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace BookStore.Models
{
    public class NHibernateConfig : IDisposable
    {
        public static ISessionFactory SessionFactory;
        public static ISession Session;
        public static ITransaction Transaction;


        public NHibernateConfig()
        {
             SessionFactory = CreateSessionFactory();
             Session = SessionFactory.OpenSession(); 
            Transaction = Session.BeginTransaction();

            /* ISessionFactory sessionFactory = Fluently
                 .Configure()
                .Database(MsSqlConfiguration.MsSql2012
                .ConnectionString(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Books;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False")
                .ShowSql())
                .Mappings(b => b.FluentMappings.AddFromAssemblyOf<Book>())
                .Mappings(a => a.FluentMappings.AddFromAssemblyOf<Author>())
                .ExposeConfiguration(cfg => new SchemaExport(cfg)
                .Create(false, false))
                .BuildSessionFactory();
             return sessionFactory.OpenSession(); */
        }
            public static ISession OpenSession()
            {
           /*     var dbString = System.Configuration.ConfigurationManager.AppSettings[@"C:\\BookStore\Script.sql"];

            ISessionFactory SessionFac = SessionFactory ?? (SessionFactory = Fluently.Configure()
                .Database(MsSqlConfiguration.MsSql2008
                .ConnectionString(@"Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = Books; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False")
                .ShowSql())
                .Mappings(x => x.FluentMappings.AddFromAssembly(Assembly.GetExecutingAssembly()))
                .ExposeConfiguration(cfg => new SchemaExport(cfg)
                .SetOutputFile(dbString.ToString())
                .Create(false, true))
                .BuildSessionFactory());*/

             return Session; 

        }

        private ISessionFactory CreateSessionFactory()
        {
            var dbString = System.Configuration.ConfigurationManager.AppSettings[@"C:\\BookStore\Script.sql"];

            return SessionFactory ?? (SessionFactory = Fluently.Configure()
                .Database(MsSqlConfiguration.MsSql2008
                .ConnectionString(@"Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = Books; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False")
                .ShowSql())
                .Mappings(x => x.FluentMappings.AddFromAssembly(Assembly.GetExecutingAssembly()))
                .ExposeConfiguration(cfg => new SchemaExport(cfg)
                .SetOutputFile(dbString.ToString())
                .Create(false, true))
                .BuildSessionFactory());
        }

        public void Dispose()
        {
            if (SessionFactory != null)
            {
                SessionFactory.Dispose();
            }
        }
    }
}

