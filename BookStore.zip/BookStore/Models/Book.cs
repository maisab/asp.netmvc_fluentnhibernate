﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookStore.Models
{
    public class Book
    {
        public virtual int Id { get; protected set; }
        public virtual string Title { get; set; }
        public virtual int Pages { get; set; }
        public virtual int PurchasePrice { get; set; }
        public virtual int SalePrice { get; set; }

        private readonly IList<Author> _authors;
        public virtual IEnumerable<Author> Authors { get { return _authors; } }
    }
}
