﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BookStore.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NHibernate;

namespace BookStore.Controllers
{
    public class BookController : Controller
    {
        // GET: Book
        public ActionResult Index()
        {
            using (NHibernate.ISession session = NHibernateConfig.OpenSession())
            {
                var books = session.Query<Book>().ToList();
                return View(books);
            }
        }

        // GET: Book/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Book/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Book/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Author author)
        {
            try
            {
                using (NHibernate.ISession session = NHibernateConfig.OpenSession())
                {
                    using (ITransaction transaction = session.BeginTransaction())
                    {
                        session.Save(author);
                        transaction.Commit();
                    }
                }

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Book/Edit/5
        public ActionResult Edit(int id)
        {
            using (NHibernate.ISession session = NHibernateConfig.OpenSession())
            {
                var book = session.Get<Book>(id);
                return View(book);
            }
        }

        // POST: Book/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Book book)
        {
            try
            {
                using (NHibernate.ISession session = NHibernateConfig.OpenSession())
                {
                    var bookUpdate = session.Get<Book>(id);

                    bookUpdate.PurchasePrice = book.PurchasePrice;
                    bookUpdate.SalePrice = book.SalePrice;
                    bookUpdate.Pages = book.Pages;

                    using (ITransaction transaction = session.BeginTransaction())
                    {
                        session.Save(bookUpdate);
                        transaction.Commit();
                    }
                }
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Book/Delete/5
        public ActionResult Delete(int id)
        {
            using (NHibernate.ISession session = NHibernateConfig.OpenSession())
            {
                var bookDelete = session.Get<Book>(id);
                return View(bookDelete);
            }
        }

        // POST: Book/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, Book book)
        {
            try
            {
                using (NHibernate.ISession session = NHibernateConfig.OpenSession())
                {
                    using (ITransaction transaction = session.BeginTransaction())
                    {
                        session.Delete(book);
                        transaction.Commit();
                    }
                }
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}